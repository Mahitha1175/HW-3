package application;

import static org.junit.jupiter.api.Assertions.*;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

/**
 * A test class that verifies various password validation scenarios
 * using the PasswordEvaluator class.
 */
public class PasswordEvaluationTests {

    /**
     * Resets any static state in PasswordEvaluator before each test.
     */
    @BeforeEach
    public void setup() {
        // Reset any static states if necessary in PasswordEvaluator
    }

    /**
     * Tests that a properly formatted password passes validation.
     */
    @Test
    public void testValidPassword() {
        String input = "Aa!15678";
        String result = PasswordEvaluator.evaluatePassword(input);
        assertEquals("", result, "Password should be valid but returned error.");
    }

    /**
     * Tests that a short password without required elements is rejected.
     */
    @Test
    public void testInvalidPasswordShort() {
        String input = "A!";
        String result = PasswordEvaluator.evaluatePassword(input);
        assertNotEquals("", result, "Password should be invalid but passed.");
    }

    /**
     * Verifies that a valid password is not incorrectly rejected.
     */
    @Test
    public void testIncorrectExpectedFail() {
        String input = "Aa!15678";
        String result = PasswordEvaluator.evaluatePassword(input);
        assertEquals("", result, "Expected valid password.");
    }

    /**
     * Verifies that a short invalid password is not incorrectly accepted.
     */
    @Test
    public void testIncorrectExpectedPass_A() {
        String input = "A!";
        String result = PasswordEvaluator.evaluatePassword(input);
        assertNotEquals("", result, "Expected invalid password.");
    }

    /**
     * Ensures that an empty password is correctly flagged as invalid.
     */
    @Test
    public void testEmptyPassword() {
        String input = "";
        String result = PasswordEvaluator.evaluatePassword(input);
        assertNotEquals("", result, "Empty password should be invalid.");
    }
}
